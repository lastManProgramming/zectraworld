(function () {
    angular.module('Zectranet.project', []);
})();