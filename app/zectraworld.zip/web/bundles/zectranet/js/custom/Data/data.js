(function(){
    angular.module('Zectranet.data', []);
})();