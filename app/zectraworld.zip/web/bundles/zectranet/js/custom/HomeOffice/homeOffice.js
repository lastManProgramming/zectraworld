(function () {
    angular.module('Zectranet.homeOffice', []);
})();