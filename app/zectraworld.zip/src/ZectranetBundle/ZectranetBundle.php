<?php

namespace ZectranetBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ZectranetBundle extends Bundle
{
}
